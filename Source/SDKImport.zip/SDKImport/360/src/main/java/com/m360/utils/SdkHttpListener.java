
package com.m360.utils;

public interface SdkHttpListener {

    public void onResponse(String response);

    public void onCancelled();

}

package qq;

import com.tencent.tauth.IUiListener;
import com.tencent.tauth.UiError;

import org.json.JSONObject;

public class BaseUiListener implements IUiListener {


    protected void doComplete(JSONObject values) {

    }

    @Override
    public void onComplete(Object o) {

    }

    @Override
    public void onError(UiError e) {

    }

    @Override

    public void onCancel() {

    }

}

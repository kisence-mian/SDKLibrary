package sdkInterface.activity;

import android.content.Intent;
import android.os.Bundle;

import com.unity3d.player.UnityPlayerActivity;

import sdkInterface.SdkInterface;

public class MainActivity extends UnityPlayerActivity
{
    @Override
    //获取回调并派发给SDKInterface
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        SdkInterface.onActivityResult(requestCode,resultCode,data);
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        SdkInterface.OnCreate();
    }

    @Override
    protected void onPause() {
        super.onPause();
        SdkInterface.OnPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        SdkInterface.OnResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SdkInterface.OnDestroy();
    }
}

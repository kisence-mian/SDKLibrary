package sdkInterface.define;

public enum GoodsType {
    NORMAL,    //可以反复购买的商品
    ONCE_ONLY, //只能购买一次的商品
    RIGHTS,    //购买持续一段时间的商品，例如会员
}

package sdkInterface;

import org.json.JSONObject;

/**
 * Created by GaiKai on 2018/4/12.
 */

public interface IOther
{
   void Other(JSONObject json);

   String[] GetFunctionName();
}
